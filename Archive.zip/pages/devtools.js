//console.log(111);

//console.log(chrome.devtools.inspectedWindow.tabId);
//document.querySelector('#test').innerHTML(chrome.devtools.inspectedWindow.tabId);
//document.getElementById('test').innerHTML = chrome.devtools.inspectedWindow.tabId;
//chrome.devtools.inspectedWindow.getResources(function callback(resources){
//    document.getElementById('test2').innerHTML = '2';
////    console.log(resources);
//    resources.forEach(function(elem){
//        console.log(elem);
//    });
//});